class Osoba():
    def __init__(self, imieWpisane, nazwiskoWpisane, wiekWpisany):
        #konstruktor
        self._imie = imieWpisane #wlasnosc prywatna to __ przed zmienna
        self._nanzwisko = nazwiskoWpisane #wlasnosc protected
        self.wiek = wiekWpisany #wlasnosc public

    def __str__(self):
        return "imie: "+self._imie+" nazwisko: "+self._nanzwisko+" wiek: "+str(self.wiek)

    def getImie(self):
        return self._imie

    def getNazwisko(self):
        return self._nanzwisko


class Uczen(Osoba):
    licznikObiektow = 0
    def __init__(self, imie, nazwisko, wiek, klasa):
        Osoba.__init__(self, imie, nazwisko, wiek)
        self.klasa = klasa
        Uczen.licznikObiektow += 1
    def __str__(self):
        return "imie: "+self.getImie()+" nazwisko: "+self.nazwisko
#-------- program główny

osoba = Osoba("Jaś","Nowak",34)
print(osoba.getImie())
print(osoba.getNazwisko())
print(osoba)

print(Uczen.licznikObiektow)
uczen = Uczen("ed","fred","3s",32)
print(Uczen.licznikObiektow)