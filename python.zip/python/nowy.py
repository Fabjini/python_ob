class Osoba():
    licznikInstancji = 0
    def __init__(self, imie = "", id=0):
        self.__imie = imie
        self.__id = id
        Osoba.licznikInstancji += 1

    def wypiszImie(self, argument):
        if self.__imie == "":
            print("brak danych")
        else:
            print("Cześć "+argument+" mam na imie "+self.__imie)

    def __copy__(self):
        nowa_osoba = self.__imie, self.__id
        return  nowa_osoba

print("licznik zarejestrowanych osób "+str(Osoba.licznikInstancji))
osoba1 = Osoba()

print("licznik zarejestrowanych osób "+str(Osoba.licznikInstancji))
imie = input("podaj imie")
id = int(input("podaj id"))
osoba2 = Osoba(imie, id)


print("licznik zarejestrowanych osób "+str(Osoba.licznikInstancji))
osoba3 = osoba2.__copy__()
